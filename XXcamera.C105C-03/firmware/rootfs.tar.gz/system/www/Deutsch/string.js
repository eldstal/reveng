var str_sun='Sonntag';
var str_mon='Montag';
var str_tue='Dienstag';
var str_wed='Mittwoch';
var str_thu='Donnerstag';
var str_fri='Freitag';
var str_sat='Samstag';
var str_day='Tag';
var str_schedule='Zeitplanung';

var str_record_osd='Zeitmarke zu Aufnahme hinzufgen';

var str_rebootinfo='Kamera wird neu gestartet. Nicht ausschalten. Bitte warten...';

var str_refreshcameraparams='Kamera Parameter aktualisieren';

var str_refreshvideo='Video aktualisieren';

var str_alarmstatus='Alarm Status';

var str_motion_alarm='Bewegungserkennung Alarm';

var str_input_alarm='Input Alarm';

var str_livevideo='Live Video';

var str_devicemanagement='Gert Management';

var str_buffer='Audio Puffer';

var str_osd_option = '<option>deaktiviert</option><option>schwarz</option><option>gelb</option><option>rot</option><option>Wei</option><option>blau</option>';

var str_reversal = 'um 180drehen';

var str_mirror = 'spiegeln';

var str_anonymous = 'Anonym';

var str_signin2device = 'Anmelden';

var str_mode_activex='ActiveX Modus (Fr Internet Explorer)';

var str_mode_serverpush='Server Push Modus (Firefox, Google, etc.)';

var str_user = 'Benutzer';

var str_pwd = 'Passwort';

var str_signin = 'Anmelden';

var str_attention = 'Wichtig::';

var str_attention1 = 'Gro- Kleinschreibung beachten';

var str_attention2 = 'Bildschirmauflsung 1024x768 verwenden';

var str_devicestatus = 'Gertestatus';

var str_4visitor = 'Gast';

var str_4operator = 'Benutzer';

var str_4administrator = 'Administrator';

var str_configdevice = 'Gertekonfiguration';

var str_talk = 'sprechen';

var str_audio = 'Audio';

var str_video = 'Video';

var str_play = 'Abspielen';

var str_stop = 'Stop';

var str_snapshot = 'Schnappschuss';

var str_record = 'Aufnehmen';

var str_alias = 'Kameraname';

var str_switch = 'Switch';

var str_switchon = 'Switch on';

var str_switchoff = 'Switch off';

var str_open = 'ffnen';

var str_close = 'Schlieen';

var str_resolution = 'Auflsung';

var str_mode = 'Modus';

var str_brightness = 'Helligkeit';

var str_contrast = 'Kontrast';

var str_outdoor = 'Drauen';

var str_default = 'Standard';

var str_unselected = 'nicht ausgewhlt';

var str_device = 'Gert';

var str_err_connect = 'Verbindung nicht mglich';

var str_err_socket = 'Sockel Fehler';

var str_err_timeout = 'Zeitberschreitung';

var str_err_version = 'Falsche Softwareversion';

var str_err_cancel = 'Durch Benutzer abgebrochen';

var str_err_closed = 'Verbindung durch Gert getrennt';

var str_err_file = 'Dateifehler';

var str_err_param = 'Falscher Parameter';

var str_err_thread = 'Threadfehler';

var str_err_status = 'Status nicht zulssig';

var str_err_id = 'Gertename falsch';

var str_fail_user = 'Benutzername falsch';

var str_fail_maxconns = 'Maximale Anzahl an Verbindungen erreicht.';

var str_fail_version = 'Falsche Softwareversion';

var str_fail_id = 'Gertename falsch';

var str_fail_pwd = 'Passwort falsch';

var str_fail_pri = 'Zugriff nicht erlaubt';

var str_fail_unsupport = 'Funktion wird nicht untersttzt';

var str_err_unknown = 'unbekannter Fehler';

var str_failtoconnect = 'Verbindung mit der Kamera fehlgeschlagen.';

var str_failtorecord = 'Aufnahme fehlgeschlagen';

var str_failtoplayvideo = 'Video abspielen fehlgeschlagen';

var str_failtoplayaudio = 'Audio abspielen fehlgeschlagen';

var str_failtostarttalk = 'Sprechen fehlgeschlagen';

var str_save = 'Speichern';

var str_dev_info = 'Gerte Information';

var str_alias_config = 'Benutzer Einstellungen';

var str_goback = 'zurck';

var str_datetime_config = 'Datum&Zeit Einstellungen';

var str_users_config = 'Benutzer Einstellungen';

var str_multidevice_config = 'Mehrere Kameras verwalten';

var str_network_config = 'Netzwerk Einstellungen';

var str_wireless_config = 'Wireless Lan Einstellungen';

var str_adsl_config = 'ADSL Einstellungen';

var str_upnp_config = 'UPnP Einstellungen';

var str_ddns_config = 'DynDNS Einstellungen';

var str_mail_config = 'E-Mail Einstellungen';

var str_ftp_config = 'FTP Einstellungen';

var str_alarm_config = 'Alarm Einstellungen';

var str_upgrade_firmware = 'Firmware aktualisieren';

var str_restore_factory = 'Auslieferungszustand wiederherstellen';

var str_reboot = 'Kamera neu starten';

var str_dev_id = 'Kamera ID';

var str_sw_ver = 'Firmware Version';

var str_aw_ver = 'Benutzeroberflche Version';

var str_set = 'bernehmen';

var str_failtoset = 'Einstellungen konnten nicht gespeichert werden';

var str_oktoset = 'Einstellungen wurden gespeichert';

var str_oktoset_reboot = 'Einstellungen wurden gespeichert. Gert wird neu gestartet.';

var str_failtoreboot = 'Neustart fehlgeschlagen';

var str_oktoreboot = 'Die Kamera wird neu gestartet';

var str_failtorestore = 'Auslieferungszustand konnte nicht wiederhergestellt werden';

var str_oktorestore = 'Auslieferungszustand wurde wiederhergestellt. Gert wird neu gestartet';

var str_upgrade_swware = 'Firmware aktualisieren';

var str_upgrade_awware = 'Benutzeroberflche aktualisieren';

var str_failtoupgrade = 'Aktualisierung fehlgeschlagen';

var str_oktoupgrade='Aktualisiere ... Gert nicht ausschalten!';

var str_upgrading_progress = 'Status';

var str_group = 'Benutzergruppe';

var str_pri_list='<option>Gast</option><option>Benutzer</option><option>Administrator</option>';

var str_visitor = 'Gast';

var str_operator = 'Benutzer';

var str_administrator = 'Administrator';

var str_refresh = 'aktualisieren';

var str_device_clock_time = 'Gerteuhrzeit';

var str_failtofetch = 'Parameter konnte nicht abgerufen werden';

var str_device_tz = 'Gerteuhrzeit Zeitzone';

var str_ntp_choice = 'Mit NTP Server synchronisieren';

var str_ntp_server = 'NTP Server';

var str_syncwithpc = 'Mit PC Zeit synchronisieren';

var str_dhcp_choice = 'IP Adresse von DHCP Server beziehen';

var str_ip = 'IP Adresse';

var str_mask = 'Subnetzmaske';

var str_gateway = 'Gateway';

var str_dns = 'DNS Server';

var str_port = 'Http Port';

var str_adsl_choice = 'ADSL Verbindung verwenden';

var str_adsl_user = 'ADSL Benutzer';

var str_adsl_pwd = 'ADSL Passwort';

var str_mail_inet_ip = 'externe IP Adresse per Email mitteilen';

var str_upnp_choice = 'Verwende UPnP um einen Port zu mappen.';

var str_upnp_status = 'UPnP Status';

var str_upnp_msg0 = 'Keine Aktion';

var str_upnp_msg1 = 'UPnP: Erfolgreich gestartet';

var str_upnp_msg2 = 'UPnP: Gertefehler';

var str_upnp_msg3 = 'UPnP: Netzwerkfehler';

var str_upnp_msg4 = 'UPnP: Kommunikation mit UPnP Gert nicht mglich';

var str_upnp_msg5 = 'UPnP: Portfehler';

var str_sender = 'Sender';

var str_receiver = 'Empfnger';

var str_smtp_svr = 'SMTP Server';

var str_smtp_auth = 'Benutzerauthentifizierung ntig';

var str_smtp_user = 'SMTP Benutzer';

var str_smtp_pwd = 'SMTP Passwort';

var str_ftp_svr = 'FTP Server';

var str_ftp_port = 'FTP Port';

var str_ftp_user = 'FTP Benutzer';

var str_ftp_pwd = 'FTP Passwort';

var str_ftp_dir = 'FTP Pfad';

var str_ftp_mode = 'FTP Modus';

var str_ftp_upload_enable = 'Bild jetzt Hochladen';

var str_ftp_upload_interval = 'Intervall (Sekunden)';

var str_ie_protected_mode_info='Aufnahme nicht mglich. Gert muss zu den Vertrauenswrdigen Seiten im Internet Explorer hinzugefgt werden. (IE Einstellungen > Internet Optionen > Sicherheits Einstellungen > Vertrauenswrdige Seiten)';

var str_motion_enable = 'Bewegungserkennung';

var str_motion_sensitivity = 'Sensibilitt';

var str_high = 'Hoch';

var str_medium = 'Mittel';

var str_low = 'Niedrig';

var str_extern_enable = 'Alarm Input Armed';

var str_alarm_mail_enable = 'E-Mail verschicken';

var str_alarm_ftp_enable = 'Bild Hochladen';

var str_alarm_linkage_enable = 'IO Linkage on Alarm';

var str_ddns_service = 'DDNS Service';

var str_ddns_user = 'DDNS Benutzer';

var str_ddns_pwd = 'DDNS Passwort';

var str_ddns_host = 'DDNS Adresse';

var str_proxy_svr = 'DDNS- oder Proxy Server';

var str_proxy_port = 'DDNS- oder Proxy Port';

var str_ddns_status = 'DDNS Status';

var str_ddns_service_list = '<option value=0>None</option><option value=1>Oray.net</option><option value=2>DynDns.org(dyndns)</option><option value=3>DynDns.org(statdns)</option><option value=4>DynDns.org(custom)</option><option value=8>3322.org(dyndns)</option><option value=9>3322.org(statdns)</option>';

var str_restart_dyndns = 'Fehler ignorieren';

var str_dyndns_proxy_comment = 'Proxy Konfiguration wird bentigt falls sich der Standort in China oder Hongkong befindet';

var str_restart_dyndns_comment = 'Nicht aktivierensolange der Hostname nicht freigegeben wurde';

var str_ddns_noaction = 'Keine Aktion';

var str_ddns_waiting='Verbindung wird hergestellt ...';

var str_ddns_cannotconnect = 'Netzwerkfehler';

var str_easynx_ok = 'EasyNX: Erfolgreich gestartet';

var str_easynx_noauth = 'EasyNX: Benutzername oder Passwort falsch';

var str_easynx_noid = 'EasyNX: Dieses Benutzerkonto existiert nicht.';

var str_easynx_over = 'EasyNX: Benutzerkonto ist abgelaufen';

var str_easynx_iddisable = 'EasyNX: Benutzerkonto ist deaktiviert';

var str_easynx_errparam = 'EasyNX: Falsche Parameter';

var str_easynx_unknownerr = 'EasyNX: unbekannter Fehler';

var str_3322_ok = '3322: Erfolgreich gestartet';

var str_3322_sys_err = '3322: Dyndns.org Systemfehler';

var str_3322_badauth = '3322: Benutzername oder Passwort falsch';

var str_3322_donator = '3322: freigeschalteter Benutzer ntig';

var str_3322_notfqdn = '3322: Host Format falsch';

var str_3322_nohost = '3322: Host existiert nicht';

var str_3322_yours = '3322: Host und Benutzerkonto stimmen nicht berein';

var str_3322_numhost = '3322: Zu viele Hosts';

var str_3322_abuse = '3322: Host wurde gesperrt';

var str_3322_server_err = '3322: Dyndns.org Serverfehler';

var str_3322_chat_err = '3322: Falsche Antwort vom Server';

var str_dyndns_ok = 'DynDNS erfolgreich gestartet';

var str_dyndns_sys_err = 'DynDNS: Dyndns.org Systemfehler';

var str_dyndns_badauth = 'DynDNS: Benutzername oder Passwort falsch';

var str_dyndns_donator = 'DynDNS: Freigeschalteter Benutzer ntig';

var str_dyndns_notfqdn = 'DynDNS: Host Format falsch';

var str_dyndns_nohost = 'DynDNS: Host existiert nicht';

var str_dyndns_yours = 'DynDNS: Host und Benutzerkonto stimmen nicht berein';

var str_dyndns_numhost = 'DynDNS: Zu viele Hosts';

var str_dyndns_abuse = 'DynDNS: Host wurde gesperrt';

var str_dyndns_server_err = 'DynDNS: Dyndns.org Serverfehler';

var str_dyndns_chat_err = 'DynDNS: Falsche Antwort von Server';

var str_oray_chat_err = 'Oray: Falsche Antwort vom Server';

var str_oray_bad_auth = 'Oray: Benutzername oder Passwort falsch';

var str_oray_bad_host = 'Oray: Hostname falsch';

var str_oray_standard_ok = 'Oray(Standard) erfolgreich gestartet';

var str_oray_professional_ok = 'Oray(Professional) erfolgreich gestartet';

var str_ddns_ok = 'DDNS erfolgreich gestartet';

var str_ddns_failed = 'DDNS konnte nicht gestartet werden';

var str_yu_ddns_ok = 'Vidamax erfolgreich gestartet';

var str_yu_ddns_failed = 'Vidamax konnte nicht gestartet werden';

var str_devicelist_inlan = 'Gerte im Netzwerk';

var str_subnet_nomatch = 'Subnetz ist nicht korrekt';

var str_multidevice_attention = 'Achtung: Falls Sie ber das Internet auf die Kamera zugreifen mchten, bentigen Sie den Host und den zugehrigen Port.';

var str_1st_device = '1. Kamera';

var str_2nd_device = '2. Kamera';

var str_3rd_device = '3. Kamera';

var str_4th_device = '4. Kamera';

var str_5th_device = '5. Kamera';

var str_6th_device = '6. Kamera';

var str_7th_device = '7. Kamera';

var str_8th_device = '8. Kamera';

var str_9th_device = '9. Kamera';

var str_none = 'Keine';

var str_this_device = 'Diese Kamera';

var str_host = 'Gastgeber';

var str_add = 'Hinzufgen';

var str_remove = 'Entfernen';

var str_wifi_choice = 'Wireless Lan verwenden';

var str_wifi_encryption = 'Verschlsselung';

var str_wifi_wep_key_index = 'Standardschlssen';

var str_wifi_wep_key1 = 'Schlssel 1';

var str_wifi_wep_key2 = 'Schlssel 2';

var str_wifi_wep_key3 = 'Schlssel 3';

var str_wifi_wep_key4 = 'Schlssel 4';

var str_wifi_channel = 'Kanal';

var str_wifi_authtype = 'Authentifizierung';

var str_auth_open = 'Open System';

var str_auth_share = 'Schlssel';

var str_wifi_keytype = 'Schlssel Format';

var str_hex = 'Hexadezimal';

var str_ascii = 'ASCII';

var str_sure_reboot = 'Kamera wirklich neu starten?';

var str_sure_restore = 'Auslieferungszustand wirklich herstellen?';

var str_center = 'zentriert';

var str_vertical_patrol = 'Vertical patrol';

var str_horizon_patrol = 'Horizon patrol';

var str_stop_vertical_patrol = 'Stop vertical patrol';

var str_stop_horizon_patrol = 'Stop horizon patrol';

var str_start = 'Starten';

var str_test = 'Test';

var str_succeed = 'Erfolgreich!';

var str_failed = 'Nicht erfolgreich!';

var str_ftp_error_connect = 'Verbindung mit dem Server kann nicht hergestellt werden.';

var str_ftp_error_network = 'Netzwerkfehler. Bitte versuchen Sie es spter!';

var str_ftp_error_server = 'Server fehler';

var str_ftp_error_user = 'Benutzername oder Passwort falsch';

var str_ftp_error_pwd = 'Benutzername oder Passwort falsch';

var str_ftp_error_dir = 'Kein Zugriff auf Ordner mglich. Bitte stellen Sie sicher, dass der Ordner existiert und Sie ausreichende Zugriffsrechte besitzen.';

var str_ftp_error_pasv = 'PASV Modus Fehler. Stellen Sie sicher dass der Server PASV untersttzt.';

var str_ftp_error_port = 'Fehler in PORT Modus. PASV Modus sollte aktiviert sein.';

var str_ftp_error_stor = 'Datei konnte nicht hochgeladen werden. Bitte stellen Sie sicher dass Sie ausreichende Zugriffsrechte besitzen.';

var str_smtp_error_connect = 'Verbindung mit dem Server kann nicht hergestellt werden.';

var str_smtp_error_network = 'Netzwerk fehler. Bitte versuchen Sie es spter.';

var str_smtp_error_server = 'Server fehler';

var str_smtp_error_user = 'Benutzername oder Passwort falsch';

var str_smtp_error_pwd = 'Benutzername oder Passwort falsch';

var str_smtp_error_sender = 'Der Sender wurde vom Server abgewiesen.';

var str_smtp_error_receiver	= 'Der Empfnger wurde von Server abgewiesen.';

var str_smtp_error_message = 'Die Nachricht wurde von Server abgewiesen.';

var str_smtp_error_auth	 = 'Die von der Kamera verwendete Authentifizierungsmethode wird vom Server nicht untersttzt.';

var str_test_info='Bitte nehmen Sie alle Einstellungen vor, bevor Sie mit dem Test beginnen.';

var str_lowest='Niedrigste';

var str_wifi_mode_list='<option>Access Point</option><option>Peer to Peer</option>';

var str_smtp_port='SMTP Port';

var str_tz_list='<option value=39600>(GMT -11:00) Midway Islands, Samoa Islands</option><option value=36000>(GMT -10:00) Hawaii</option><option value=32400>(GMT -09:00) Alaska Standard</option><option value=28800>(GMT -08:00) Pacific Standard(USA and Canada)</option><option value=25200>(GMT -07:00) Mountain Standard(USA and Canada)</option><option value=21600>(GMT -06:00) Central Standard(USA and Canada), Mexico City</option><option value=18000>(GMT -05:00) Eastern Standard(USA and Canada), Lima, Bogota</option><option value=14400>(GMT -04:00)Atlantic Standard (Canada), Santiago, La Paz</option><option value=12600>(GMT -03:30) Newfoundland</option><option value=10800>(GMT -03:00) Brasilia, Buenos Aires, Georgetown</option><option value=7200>(GMT -02:00) South Geogia I.</option><option value=3600>(GMT -01:00) Reykjavik</option><option value=0>(GMT) Greenwich mean time; London, Lisbon, Casablanca</option><option value=-3600>(GMT +01:00) Brussels, Paris, Berlin, Rome, Madrid, Stockholm, Beograd</option><option value=-7200>(GMT +02:00) Athens, Jerusalem, Cairo, Helsinki</option><option value=-10800>(GMT +03:00) Nairobi, Riyadh, Moscow</option><option value=-12600">(GMT +03:30) Tehran</option><option value=-14400>(GMT +04:00) Baku, Tbilisi, Abu Dhabi, Muscat</option><option value=-16200>(GMT +04:30) Kabul</option><option value=-18000">(GMT +05:00) Islamabad, Karachi, Tashkent</option><option value=-19800>(GMT +05:30) Bombay, Calcutta, Madras, New Delhi</option><option value=-21600>(GMT +06:00) Astana, Almaty, Dhaka, Colombo</option><option value=-25200>(GMT +07:00) Bangkok, Hanoi, Jakarta</option><option value=-28800>(GMT +08:00) Beijing, Singapore, Taipei</option><option value=-32400>(GMT +09:00) Seoul, Yakutsk, Tokyo</option><option value=-34200>(GMT +09:30) Darwin</option><option value=-36000>(GMT +10:00) Guam, Melbourne, Sydney, Port Moresby, Vladivostok</option><option value=-39600>(GMT +11:00) Magadan, Solomon Islands, New Calenonia</option><option value=-43200>(GMT +12:00) Auckland, Wellington, Fiji Islands</option>';

var str_mailtest = 'E-Mail test';

var str_mailtestPrompt = 'Bitte geben Sie die E-Mail Parameter ein und klicken Sie auf bernehmen.';

var str_Note = 'Anmerkung:';

var str_RECPath = 'Aufnahmepfad angeben';

var str_AlarmPath ='Alarm-Aufnahmepfad angeben';

var str_RECPathFail = 'Aufnahmepfad konnte nicht gefunden werden';

var str_RECPathSuccess = 'Aufnahmepfad OK';

var str_RECPathfailC = 'Das Windows-Systemverzeichniss kann als Aufnahmepfad nicht verwendet werden.';

var str_AlarmPathFail = 'Alarm-Aufnahmepfad konnte nicht gefunden werden.';

var str_AlarmPathSuccess = 'Aufnahmepfad OK';

var str_AlarmPathFailC = 'Das Windows-Systemverzeichniss kann als Aufnahmepfad nicht verwendet werden.';

var str_SetTrustedSites = 'Um Videos aufzunehmen, muss die IP-Adresse der Kamera als Vertrauenswrdige Seite im Internetexplorer eingestuft werden.';

var str_mail_inet_ip = 'Internet IP Adresse per Email senden';

var str_MailIPPrompt = 'Internet IP Adresse per Email senden wurde berprft. Sobald sich die Internet IP-Adresse ndert, wird diese per E-Mail weitergeleitet. Wenn der Kamera ein spezieller Port zugewiesen wurde, muss dieser auch vom Router weitergeleitet werden.';

var str_FTPtest = 'FTP test';

var str_FTPtestPrompt = 'Bitte geben Sie die FTP Parameter ein und klicken Sie auf bernehmen.';

var str_language ='Deutsch';

var str_ultralow = 'sehr niedrig';

var str_lansetting_err = 'Dieser Parameter kann nicht 0 sein';

var str_log = 'log';

var str_wifi_list='Verfgbare Netzwerke';

var str_scan='aktualisieren';

var str_wifi_scan_info='aktualisieren ...';

var str_led_mode = 'Network Lamp';

var str_maxvideorate = 'Fps';

var str_max = 'Max';

var str_decoder_config='Decoder Einstellungen';

var str_baud='Baudrate';

var str_backup_restore='Backup&Wieder Einstellungen';

var str_backup='Backup';

var str_restore='Wieder';

var str_wifi_networktype='Netzwerk Type';

var str_triger_level='Triger Pegel';

var str_output_level='Output Pegel';

var str_ptz_config='PTZ Einstellungen';

var str_autocenter='Start-Center';

var str_pt_speed='PT Geschwindigkeit';

var str_up_speed='Oben Geschwindigkeit';

var str_down_speed='Nach unten Geschwindigkeit';

var str_left_speed='Links Geschwindigkeit';

var str_right_speed='Recht Geschwindigkeit';

var str_yu_ddns_service_list = '<option value=0> Nein </ option> <option value=1> Erdnuss-Schale </ option> <option value=2> DynDns.org (DynDNS) </ option> <option value=3> DynDns . org (statdns) </ option> <option value=4> DynDns.org (custom) </ option> <option value=8> 3322.org (DynDNS) </ option> <option value=9> 3322.org (statdns) </ option> <option value=5> Jiangxi Telecom </ option> <option value=6> VidaMax </ option> <option value=7> EasyNX.cn </ option> '; 

var str_psd_ddns_service_list = '<option value=0> Nein </ option> <option value=7> IPCam </ option> <option value=1> Erdnuss-Schale </ option> <option value=2> DynDns.org (DynDNS) </ option> <option value=3> DynDns.org (statdns) </ option> <option value=4> DynDns.org (custom) </ option> <option value=8> 3322.org (DynDNS) </ option> <option value=9> 3322.org (statdns) </ option> '; 

var str_fail_forbidden = 'Derzeit ist diese Funktion verboten ist'; 

var str_p2p_status = 'P2P-Staat '; 

var str_p2p_msg0 = 'no action'; 

var str_p2p_msg1 = 'Konnte keine Verbindung zum Server'; 

var str_p2p_msg2 = 'Verbindung zum Server ...'; 

var str_p2p_msg3 = 'mit der Server-Verbindung Zeitberschreitung trennen'; 

var str_p2p_msg4 = 'eine erfolgreiche Verbindung mit dem Server, die lokale Abhrport:'; 

var str_mode_Mobile = 'Keine Plug-In-Modus (fr Smartphone-Browser)'; 

var str_Ptz_UpText = 'on'; 

var str_Ptz_DownText = "next"; 

var str_Ptz_LeftText = "links"; 

var str_Ptz_RightText = 'right'; 

var str_Ptz_StopText = "center"; 

var str_Ptz_FastText = 'schnell'; 

var str_Ptz_SlowText = 'langsame'; 

var str_PresetTitle = 'pre-Position '; 

var str_CallPreset = 'rufen'; 

var str_SetPreset = 'Einstellungen'; 

var str_forbidden_config = 'Verbot der Ansicht Audio-und Video-Einstellungen '; 

var str_zoom_plus = 'Zoom +'; 

var str_zoom_minus = 'Zoom -'; 

var str_alarm_http_enable = 'Alarm Http Bekanntmachung '; 

var str_alarm_http_url = 'http-URL';

var str_BrowseBtn = 'Durchsuchen ...';

var str_MaxRate ='Bildfrequenz';
var str_PresetGroup = 'Kreuzfahrt-Gruppe ';
var str_PresetGroup_Excute = 'Umsetzung';
var str_PresetGroup_Cancel = 'Abbrechen';
var str_PresetGroup_Tip = 'Kreuzfahrt group script: \n\n wie: \n\np1w5p2w10: Rufen Sie die voreingestellte Position, sagte ein Aufenthalt f��r 5 Sekunden gedr��ckt, und rufen dann die voreingestellte Position 2 bis 10 Sekunden, wiederholen zu bleiben. \n\n Hinweis: Verweilzeit in Sekunden und muss gr??er als 5 Sekunden, um wirksam sein werden. ';
var str_motion_preset='Alarm voreingestellte Verkn??pfung';