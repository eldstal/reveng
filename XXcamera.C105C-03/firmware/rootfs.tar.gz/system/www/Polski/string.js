var str_sun='Nie';

var str_mon='Pon';

var str_tue='Wt';

var str_wed='Zr';

var str_thu='Czw';

var str_fri='Pi';

var str_sat='Sob';

var str_day='DzieD';

var str_schedule='Harmonogram';

var str_record_osd='Dodaj znacznik czasu do nagrania';

var str_rebootinfo='Restart urzdzenia. Nie odBczaj zasilania. Prosz czeka ...';

var str_refreshcameraparams='od[wie| ustawienia kamery';

var str_refreshvideo='od[wie| video';

var str_alarmstatus='Stan alarmu';

var str_motion_alarm='Czujnik ruchu';

var str_input_alarm='Wej[cie alarmu';

var str_livevideo='Live Video';

var str_devicemanagement='Zarzdzanie urzdzeniem';

var str_buffer='Bufor Audio';

var str_osd_option = '<option>wyBczona</option><option>czarny</option><option>|Bty</option><option>czerwony</option><option>biaBy</option><option>niebieski</option>';

var str_reversal = 'Obr';

var str_mirror = 'Lustrzane odbicie';

var str_anonymous = 'Anonimowy';

var str_signin2device = 'Zapisz do urzdzenia';

var str_mode_activex='ActiveX (Przegldarka IE)';

var str_mode_serverpush='Server Push Mode (Dla FireFox, Google Browser)';

var str_user = 'U|ytkownik';

var str_pwd = 'HasBo';

var str_signin = 'Login';

var str_attention = 'Uwaga:';

var str_attention1 = 'Wielko[ liter';

var str_attention2 = 'Sugerowana rozdzielczo[ 1024 * 768';

var str_devicestatus = 'Status Urzdzenia';

var str_4visitor = 'Go[';

var str_4operator = 'Operator';

var str_4administrator = 'Administrator';

var str_configdevice = 'Konfiguracja urzdzenia';

var str_talk = 'Mikrofon';

var str_audio = 'Audio';

var str_video = 'Video';

var str_play = 'Play';

var str_stop = 'Stop';

var str_snapshot = 'Zdjcie';

var str_record = 'Nagrywanie';

var str_alias = 'Alias';

var str_switch = 'PrzeBcznik alarmu';

var str_switchon = 'WBczony';

var str_switchoff = 'WyBczony';

var str_open = 'Otwrz';

var str_close = 'Zamknij';

var str_resolution = 'Rozdzielczo[';

var str_mode = 'Tryb';

var str_brightness = 'Jasno[';

var str_contrast = 'Kontrast';

var str_outdoor = 'Na zewntrz';

var str_default = 'Ustawienia domy[lne';

var str_unselected = 'Odznaczony';

var str_device = 'Urzdzenie';

var str_err_connect = 'Nie mog poBczy si z urzdzeniem';

var str_err_socket = 'BBd Socketu';

var str_err_timeout = 'Koniec czasu';

var str_err_version = 'NiewBa[ciwa wersja oprogramowania';

var str_err_cancel = 'Anulowane przez u|ytkownika';

var str_err_closed = 'OdBczony przez urzdzenie';

var str_err_file = 'BBd operacji na pliku';

var str_err_param = 'NiewBa[ciwy parametr';

var str_err_thread = 'BBd operacji na wtku';

var str_err_status = 'NiewBa[ciwy status';

var str_err_id = 'BBdna nazwa urzdzenia';

var str_fail_user = 'BBdny u|ytkownik';

var str_fail_maxconns = 'Przekroczono limit poBczeD';

var str_fail_version = 'NiewBa[ciwa wersja oprogramowania';

var str_fail_id = 'NiewBa[ciwa nazwa urzdzenia';

var str_fail_pwd = 'NiewBa[ciwe hasBo';

var str_fail_pri = 'Nieautoryzowana operacja';

var str_fail_unsupport = 'Urzdzenie nie obsBuguje tej funkcji';

var str_err_unknown = 'Nieznany bB';

var str_failtoconnect = 'BBd poBczenia z urzdzeniem';

var str_failtorecord = 'BBd podczas prby nagrania';

var str_failtoplayvideo = 'BBd podczas prby odtwarzania';

var str_failtoplayaudio = 'BBd podczas prby uruchomienia dzwiku';

var str_failtostarttalk = 'BBd podczas prby uruchomienia mikrofonu';

var str_save = 'Zapisz';

var str_dev_info = 'Informacje o urzdzeniu';

var str_alias_config = 'Ustawienia Aliasw';

var str_goback = 'Wr';

var str_datetime_config = 'Ustawienia daty oraz godziny';

var str_users_config = 'Ustawienia u|ytkownikw';

var str_multidevice_config = 'Ustawienia wielu urzdzeD';

var str_network_config = 'Podstawowe ustawienia sieci LAN';

var str_wireless_config = 'Ustawienia sieci bezprzewodowej WiFi';

var str_adsl_config = 'Ustawienia ADSL';

var str_upnp_config = 'Ustawienia UPnP';

var str_ddns_config = 'Ustawienia DDNS';

var str_mail_config = 'Ustawienia poczty e-mail';

var str_ftp_config = 'Ustawienia klienta FTP';

var str_alarm_config = 'Ustawienia alarmu';

var str_upgrade_firmware = 'Aktualizacja opgramowania';

var str_restore_factory = 'Przywr ustawienia domy[lne';

var str_reboot = 'Zrestartuj urzdzenie';

var str_dev_id = 'ID urzdzenia';

var str_sw_ver = 'Wersja oprogramowania';

var str_aw_ver = 'Wersja serwera WEB';

var str_set = 'Zatwierdz';

var str_failtoset = 'Nie mo|na ustawi parametrw';

var str_oktoset = 'Zatwierdzono ustawienia';

var str_oktoset_reboot = 'Zatwierdzono ustawienia, restart urzdzenia';

var str_failtoreboot = 'BBd podczas restartu';

var str_oktoreboot = 'Restart urzdzenia';

var str_failtorestore = 'BBd podczas przywracania ustawieD domy[lnych';

var str_oktorestore = 'Przywrcono ustawienia domy[lne, restartuj urzdzenie';

var str_upgrade_swware = 'Aktualizuj oprogramowanie kamery';

var str_upgrade_awware = 'Aktualizacja serwera kamery';

var str_failtoupgrade = 'BBd podczas aktualizacji';

var str_oktoupgrade='Aktualizacja... Nie odBczaj zasilania do puki urzdzenie si nie uruchomi !!!';

var str_upgrading_progress = 'Postp aktualizacji';

var str_group = 'Grupa';

var str_pri_list='<option>Go[</option><option>Operator</option><option>Administrator</option>';

var str_visitor = 'Go[';

var str_operator = 'Operator';

var str_administrator = 'Administrator';

var str_refresh = 'Od[wie|';

var str_device_clock_time = 'Godzina';

var str_failtofetch = 'BBd podczas aktualizacji czasu';

var str_device_tz = 'Strefa czasowa';

var str_ntp_choice = 'Synchronizuj z serwerem NTP';

var str_ntp_server = 'Serwer NTP';

var str_syncwithpc = 'Synchronizuj z czasem komputera';

var str_dhcp_choice = 'Pobierz adres z serwera DHCP';

var str_ip = 'Adres IP';

var str_mask = 'Maska';

var str_gateway = 'Brama';

var str_dns = 'Serwer DNS';

var str_port = 'Port HTTP';

var str_adsl_choice = 'U|yj wybierania ADSL';

var str_adsl_user = 'U|ytkownik ADSL';

var str_adsl_pwd = 'HasBo ADSL';

var str_mail_inet_ip = 'Dodawaj zewntrzny adres IP do wiadomo[ci e-mail';

var str_upnp_choice = 'U|ywaj UPnP do mapowania portw';

var str_upnp_status = 'Status UPnP';

var str_upnp_msg0 = 'Nieaktywny';

var str_upnp_msg1 = 'UPnP dziaBa';

var str_upnp_msg2 = 'UPnP BBd: BBd wewntrzny urzdzenia';

var str_upnp_msg3 = 'UPnP BBd: BBd komunikacji';

var str_upnp_msg4 = 'UPnP BBd: BBd negocjacji z urzdzeniem UPnP';

var str_upnp_msg5 = 'UPnP BBd: Odrzucony przez urzdzenie UPnP, mo|liwy konflikt portw';

var str_sender = 'Nadawca';

var str_receiver = 'Odbiorca';

var str_smtp_svr = 'Serwer SMTP';

var str_smtp_auth = 'Autoryzacja';

var str_smtp_user = 'U|ytkownik SMTP';

var str_smtp_pwd = 'HasBo SMTP';

var str_ftp_svr = 'Serwer FTP';

var str_ftp_port = 'Port FTP';

var str_ftp_user = 'U|ytkownik FTP';

var str_ftp_pwd = 'HasBo FTP';

var str_ftp_dir = 'Folder docelowy FTP';

var str_ftp_mode = 'Tryb FTP';

var str_ftp_upload_enable = 'WysyBaj zdjcia teraz';

var str_ftp_upload_interval = 'WysyBaj co X sekund';

var str_ie_protected_mode_info='Funkcja nagrywania nie dziaBa   IE dziaBa w trybie ochrony. Dodaj t stron do Zaufanych witryn (IE Narzdzia > Opcje internetowe > Zabezpieczenia > Zaufane witrnyny)';

var str_motion_enable = 'Czujnik ruchu uzbrojony';

var str_motion_sensitivity = 'CzuBo[ czujnika ruchu';

var str_high = 'Wysoki';

var str_medium = 'Zredni';

var str_low = 'Niski';



var str_extern_enable = 'Wej[cie Alarmu uzbrojone';

var str_alarm_mail_enable = 'Wy[lij wiadomo[ gdy nastpi zdarzenie';

var str_alarm_ftp_enable = 'WysyBaj zdjcia na serwer FTP gdy nastpi zdarzenie';

var str_alarm_linkage_enable = 'Wykorzystaj zBcze IO alarmu';

var str_ddns_service = 'UsBuga DDNS';

var str_ddns_user = 'U|ytkownik DDNS';

var str_ddns_pwd = 'HasBo DDNS';

var str_ddns_host = 'Host DDNS Host';

var str_proxy_svr = 'Serwer DDNS lub Serwer Proxy';

var str_proxy_port = 'Port serwera DDNS lub Proxy';

var str_ddns_status = 'Status DDNS';

var str_ddns_service_list = '<option value=0>{aden</option><option value=1>Oray.net</option><option value=2>DynDns.org(dyndns)</option><option value=3>DynDns.org(statdns)</option><option value=4>DynDns.org(custom)</option><option value=8>3322.org(dyndns)</option><option value=9>3322.org(statdns)</option>';

var str_restart_dyndns = 'Zaktualizuj ignorujc bBdy';

var str_dyndns_proxy_comment = 'Ustawienia Proxy s wymagane je[li urzdzenie u|ywane jest w Chinach lub HongKongu';

var str_restart_dyndns_comment = 'Nie u|ywaj tej opcji chyba |e twj Host zostaB odblokowany';

var str_ddns_noaction = 'Brak dziaBania';

var str_ddns_waiting='Aczenie ...';

var str_ddns_cannotconnect = 'BBd poBczenia sieciowego';

var str_easynx_ok = 'EasyNX dziaBa';

var str_easynx_noauth = 'EasyNX BBd: BBdny u|ytkownik lub hasBo';

var str_easynx_noid = 'EasyNX BBd: Konto nie istnieje';

var str_easynx_over = 'EasyNX BBd: Konto przeterminowane';

var str_easynx_iddisable = 'EasyNX BBd: Konto nie aktywne';

var str_easynx_errparam = 'EasyNX BBd: BBdne parametry';

var str_easynx_unknownerr = 'EasyNX BBd: Nieznany bBd';

var str_3322_ok = '3322 DziaBa';

var str_3322_sys_err = '3322 BBd: Dyndns.org BBd systemowy';

var str_3322_badauth = '3322 BBd: NiewBa[ciwa nazwa u|ytkownika lub hasBo';

var str_3322_donator = '3322 BBd: Brak [rodkw na koncie u|ytkownika';

var str_3322_notfqdn = '3322 BBd: BBdna nazwa hosta';

var str_3322_nohost = '3322 BBd: Host nie istnieje';

var str_3322_yours = '3322 BBd: Host nie nale|y do Ciebie';

var str_3322_numhost = '3322 BBd: Za du|o lub za maBo hostw';

var str_3322_abuse = '3322 BBd: Host zablokowany przed administracj';

var str_3322_server_err = '3322 BBd: Dyndns.org BBd serwera';

var str_3322_chat_err = '3322 BBd: NiewBa[ciwa odpowiedz serwera';

var str_dyndns_ok = 'DynDns DziaBa';

var str_dyndns_sys_err = 'DynDns BBd: Dyndns.org BBd systemowy';

var str_dyndns_badauth = 'DynDns BBd: NiewBa[ciwa nazwa u|ytkownika lub hasBo';

var str_dyndns_donator = 'DynDns BBd: Brak [rodkw na koncie';

var str_dyndns_notfqdn = 'DynDns BBd: Niedozwolona nazwa Hosta';

var str_dyndns_nohost = 'DynDns BBd: Host nie istnieje';

var str_dyndns_yours = 'DynDns BBd: Host nie nale|y do Ciebie';

var str_dyndns_numhost = 'DynDns BBd: Za du|o lub za maBo hostw';

var str_dyndns_abuse = 'DynDns BBd: Host zablokowany przez administracj';

var str_dyndns_server_err = 'DynDns BBd: Dyndns.org BBd serwera';

var str_dyndns_chat_err = 'DynDns BBd: NiewBa[ciwa odpowiedz serwera';

var str_oray_chat_err = 'Oray BBd: NiewBa[ciwa odpowiedz serwera';

var str_oray_bad_auth = 'Oray BBd: NiewBa[ciwa nazwa u|ytkownika lub hasBo';

var str_oray_bad_host = 'Oray BBd: BBdny Host';

var str_oray_standard_ok = 'Oray(Standard) DziaBa';

var str_oray_professional_ok = 'Oray(Professional) DziaBa';

var str_ddns_ok = 'DDNS DziaBa';

var str_ddns_failed = 'DDNS BBd';

var str_yu_ddns_ok = 'Vidamax DziaBa';

var str_yu_ddns_failed = 'Vidamax BBd';

var str_devicelist_inlan = 'Lista urzdzeD w sieci LAN';

var str_subnet_nomatch = 'BBdna Maska';

var str_multidevice_attention = 'UWAGA: Je[li chcesz si dosta do urzdzenia z Internetu zwr uwag aby wybrany port byB widziany z zewntrz.';

var str_1st_device = '1 Urzdzenie';

var str_2nd_device = '2 Urzdzenie';

var str_3rd_device = '3 Urzdzenie';

var str_4th_device = '4 Urzdzenie';

var str_5th_device = '5 Urzdzenie';

var str_6th_device = '6 Urzdzenie';

var str_7th_device = '7 Urzdzenie';

var str_8th_device = '8 Urzdzenie';

var str_9th_device = '9 Urzdzenie';

var str_none = '{adne';

var str_this_device = 'Aktualne urzdzenie';

var str_host = 'Host';

var str_add = 'Dodaj';

var str_remove = 'UsuD';

var str_wifi_choice = 'U|yj sieci bezprzewodowej';

var str_wifi_encryption = 'Szyfrowanie';

var str_wifi_wep_key_index = 'Domy[lny Klucz TX';

var str_wifi_wep_key1 = 'Klucz 1';

var str_wifi_wep_key2 = 'Klucz 2';

var str_wifi_wep_key3 = 'Klucz 3';

var str_wifi_wep_key4 = 'Klucz 4';

var str_wifi_channel = 'KanaB';

var str_wifi_authtype = 'Autoryzacja';

var str_auth_open = 'Open System';

var str_auth_share = 'Share Key';

var str_wifi_keytype = 'Format klucza';

var str_hex = 'Hex';

var str_ascii = 'ASCII';

var str_sure_reboot = 'Czy chcesz uruchomi urzdzenie ponownie?';

var str_sure_restore = 'Czy chcesz przywrci ustawienia domy[lne?';

var str_center = 'Zrodek';

var str_vertical_patrol = 'Patrol Pionowy';

var str_horizon_patrol = 'Patrol Poziomy';

var str_stop_vertical_patrol = 'Zatrzymaj Patrol Pionowy';

var str_stop_horizon_patrol = 'Zatrzymaj Patrol Poziomy';

var str_start = 'Start';

var str_test = 'Test';

var str_succeed = 'DziaBa';

var str_failed = 'BBd';

var str_ftp_error_connect = 'Nie mo|na poBczy si z serwerem';

var str_ftp_error_network = 'BBd sieci, sprbuj ponownie pzniej';

var str_ftp_error_server = 'BBd serwera';

var str_ftp_error_user = 'BBdny u|ytkownik';

var str_ftp_error_pwd = 'BBdne hasBo';

var str_ftp_error_dir = 'Brak dostpu do serwera. Upewnij si |e folder istnieje i masz do niego uprawnienia';

var str_ftp_error_pasv = 'BBd w trybie pasywnym. Upewnij si |e serwer obsBuguje tryb pasywny';

var str_ftp_error_port = 'BBd w trybie aktywnym. Tryb pasywny powinien by wybrany je[li urzdzenie znajduj si za NAT';

var str_ftp_error_stor = 'Nie mo|na wysBa zdjcia. Upewnij si |e konto jest aktywne';

var str_smtp_error_connect = 'Nie mo|na poBczy si z serwerem';

var str_smtp_error_network = 'BBd sieci. Sprbuj pzniej';

var str_smtp_error_server = 'BBd serwera';

var str_smtp_error_user = 'BBdny u|ytkownik';

var str_smtp_error_pwd = 'BBdne hasBo';

var str_smtp_error_sender = 'Nadawca zostaB odrzucony przez serwer. By mo|e serwer wymaga autoryzacji';

var str_smtp_error_receiver	= 'Odbiorca zostaB odrzucony przez serwer. By mo|e zostaB zablokowany przez filtr anty spamowy';

var str_smtp_error_message = 'Wiadomo[ zostaBa odrzucona przez serwer. By mo|e zostaBa zablokowana przez filtr anty spamowy';

var str_smtp_error_auth	 = 'Serwer nie obsBuguje autoryzacji wyko|ystywanej przez urzdzenie';

var str_test_info='Najpierw skonfiguruj, nastpnie wykonaj test.';

var str_lowest='Ni|szy';

var str_wifi_mode_list='<option>Access Point</option><option>Ad hoc</option>';

var str_smtp_port='Port SMTP';

var str_tz_list='<option value=39600>(GMT -11:00) Midway Islands, Samoa Islands</option><option value=36000>(GMT -10:00) Hawaii</option><option value=32400>(GMT -09:00) Alaska Standard</option><option value=28800>(GMT -08:00) Pacific Standard(USA and Canada)</option><option value=25200>(GMT -07:00) Mountain Standard(USA and Canada)</option><option value=21600>(GMT -06:00) Central Standard(USA and Canada), Mexico City</option><option value=18000>(GMT -05:00) Eastern Standard(USA and Canada), Lima, Bogota</option><option value=14400>(GMT -04:00)Atlantic Standard (Canada), Santiago, La Paz</option><option value=12600>(GMT -03:30) Newfoundland</option><option value=10800>(GMT -03:00) Brasilia, Buenos Aires, Georgetown</option><option value=7200>(GMT -02:00) South Geogia I.</option><option value=3600>(GMT -01:00) Reykjavik</option><option value=0>(GMT) Greenwich mean time; London, Lisbon, Casablanca</option><option value=-3600>(GMT +01:00) Bruksela, Pary|, Berlin,  Warszawa, Rzym, Madryd, Sztokholm</option><option value=-7200>(GMT +02:00) Athens, Jerusalem, Cairo, Helsinki</option><option value=-10800>(GMT +03:00) Nairobi, Riyadh, Moscow</option><option value=-12600">(GMT +03:30) Tehran</option><option value=-14400>(GMT +04:00) Baku, Tbilisi, Abu Dhabi, Muscat</option><option value=-16200>(GMT +04:30) Kabul</option><option value=-18000">(GMT +05:00) Islamabad, Karachi, Tashkent</option><option value=-19800>(GMT +05:30) Bombay, Calcutta, Madras, New Delhi</option><option value=-21600>(GMT +06:00) Astana, Almaty, Dhaka, Colombo</option><option value=-25200>(GMT +07:00) Bangkok, Hanoi, Jakarta</option><option value=-28800>(GMT +08:00) Beijing, Singapore, Taipei</option><option value=-32400>(GMT +09:00) Seoul, Yakutsk, Tokyo</option><option value=-34200>(GMT +09:30) Darwin</option><option value=-36000>(GMT +10:00) Guam, Melbourne, Sydney, Port Moresby, Vladivostok</option><option value=-39600>(GMT +11:00) Magadan, Solomon Islands, New Calenonia</option><option value=-43200>(GMT +12:00) Auckland, Wellington, Fiji Islands</option>';

var str_mailtest = 'Test poczty e-mail';

var str_mailtestPrompt = 'Ustaw parametry poczty e-mail, nastpnie kliknij "Wy[lij".';

var str_Note = 'Zwr uwag:';

var str_RECPath = 'Ustaw [cie|k do nagraD';

var str_AlarmPath ='Ustaw [cie|k nagraD alarmowych';

var str_RECPathFail = 'BBd podczas ustawiania [cie|ki zapisu';

var str_RECPathSuccess = 'Zcie|ka zapisu ustawiona prawidBowo';

var str_RECPathfailC = 'BBd podczas ustawiania [cie|ki. Nie mo|esz ustawi gBwnego katalogu Windows!';

var str_AlarmPathFail = 'BBd podczas ustawiania [cie|ki nagraD alarmowych!';

var str_AlarmPathSuccess = 'Zcie|ka nagraD alarmowych ustawiona prawidBowo';

var str_AlarmPathFailC = 'BBd podczas ustawiania [cie|ki nagraD alarmowych. Nie mo|esz ustawi gBwnego katalogu Windows!';

var str_SetTrustedSites = 'Aby nagrywa, musisz doda adres IP kamery to witryn zaufanych przegldarki IE!"+"\n"+"';

var str_mail_inet_ip = 'Informuj o zmianie zewntrznego adresu IP w wiadomo[ci e-mail';

var str_MailIPPrompt = '"Informuj o zmianie zewntrznego adresu IP w wiadomo[ci e-mail" gdy zaznaczone: Je[li adres IP ulegnie zmianie, zostanie wysBany w wiadomo[ci e-mail.';

var str_FTPtest = 'FTP test';

var str_FTPtestPrompt = 'Ustaw parametry FTP i kliknij "Wy[lij".';

var str_language ='Polski';

var str_ultralow = 'Najni|szy';

var str_lansetting_err = 'Parametr nie mo|e by pusty!';

var str_log = 'log';

var str_wifi_list='Lista sieci bezprzewodowych';

var str_scan='Skanuj';

var str_wifi_scan_info='Skanowanie ...';

var str_led_mode = 'Dioda informacyjna';

var str_maxvideorate = 'Fps';

var str_max = 'Max';

var str_decoder_config='Ustawienia Dekoder';

var str_baud='Szybko[ transmisji';

var str_backup_restore='Ustawienia Backup&Przywr';

var str_backup='Backup';

var str_restore='Przywr';

var str_wifi_networktype='Rodzaj sieci';

var str_triger_level='Wej[cie Poziom';

var str_output_level='Wyj[cie Poziom';

var str_ptz_config='Ustawienia PTZ';

var str_autocenter='Sprzet Start centrum';

var str_pt_speed='PT prdko[';

var str_up_speed='Wzwy| prdko[';

var str_down_speed='W dB prdko[';

var str_left_speed='Lewo prdko[';

var str_right_speed='Prawo prdko[';

var str_yu_ddns_service_list = "<option value=0> Nie </ option> <option value=1> powBoki <orzechowe / option> <option value=2> DynDns.org (dyndns) </ option> <option value=3> dyndns . org (statdns) </ option> <option value=4> DynDns.org (na zamwienie) </ option> <option value=8> 3322.org (dyndns) </ <option> opcja value=9> 3322.org (statdns) </ option> <option value=5> Jiangxi Telecom </ option> <option value=6> VidaMax </ option> <option value=7> EasyNX.cn </ option> "; 

var str_psd_ddns_service_list = "<option value=0> Nie </ option> <option value=7> IPCam </ option> <option value=1> powBoki <orzechowe / option> <option value=2> DynDns.org (dyndns) </ option> <option value=3> DynDns.org (statdns) </ option> <option value=4> DynDns.org (na zamwienie) </ option> <option value=8> 3322.org (dyndns) </ option> <option value=9> 3322.org (statdns) </ option> "; 

var str_fail_forbidden = "Obecnie ta funkcja jest zabronione"; 

var str_p2p_status = 'stan P2P'; 

var str_p2p_msg0 = 'brak dziaBaD'; 

var str_p2p_msg1 = 'Nie mo|na poBczy si z serwerem '; 

var str_p2p_msg2 = 'PoBczenie z serwerem ...'; 

var str_p2p_msg3 = 'odBczy z Przekroczono limit czasu poBczenia z serwerem'; 

var str_p2p_msg4 = 'poprawne poBczenie z serwerem, lokalny port sBuchanie muzyki: '; 

var str_mode_Mobile = 'Nie trybie Plug-In (dla smartphone przegldarki)'; 

var str_Ptz_UpText = 'on'; 

var str_Ptz_DownText = "obok"; 

var str_Ptz_LeftText = 'left'; 

var str_Ptz_RightText = "Prawo"; 

var str_Ptz_StopText = 'center'; 

var str_Ptz_FastText = "szybko"; 

var str_Ptz_SlowText = "powolny"; 

var str_PresetTitle = 'pre-position '; 

var str_CallPreset = 'PoBcz'; 

var str_SetPreset = 'Ustawienia'; 

var str_forbidden_config = 'zakaz celu ustawienia audio i wideo'; 

var str_zoom_plus = 'zoom + '; 

var str_zoom_minus = 'Zoom -'; 

var str_alarm_http_enable = 'Informacja Http alarm'; 

var str_alarm_http_url = 'http URL ';

var str_BrowseBtn = 'Przegldaj ...';

var str_MaxRate = 'Liczba klatek';
var str_PresetGroup = 'grupy wycieczkowe';
var str_PresetGroup_Excute = 'wykonanie';
var str_PresetGroup_Cancel = 'Anuluj';
var str_PresetGroup_Tip = 'Takich jak:p1w5p2w6';
var str_motion_preset='alarm ustawiony podno nik';